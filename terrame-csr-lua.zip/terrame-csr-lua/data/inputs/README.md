Coloque aqui arquivos de parâmetros/seeds (CSV/JSON etc.). Estes serão ignorados no Git por padrão.
