-- main.lua — ponto de entrada
-- Executa o autômato celular C–S–R em TerraME.
-- Ajuste caminhos/arquivos conforme sua instalação do TerraME.

local model = require("model")

-- parâmetros de execução (exemplo)
local params = {
    seed = 42,
    finalTime = 500
}

math.randomseed(params.seed)

local m = model.new(params)
m:run()

