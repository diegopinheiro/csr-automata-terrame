-- utils.lua — utilidades (placeholders)
local U = {}

function U.mooreNeighborhood(x, y)
    -- TODO: retornar vizinhos (3x3) para (x,y)
    return {}
end

function U.writeCsvLine(path, row)
    local f = io.open(path, "a")
    if f then
        f:write(table.concat(row, ",").."\n")
        f:close()
    end
end

return U
