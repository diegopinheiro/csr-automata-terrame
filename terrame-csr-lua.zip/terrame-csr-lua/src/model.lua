-- model.lua — definição do AC C–S–R (esqueleto)
local M = {}

function M.new(params)
    local self = {}

    -- TODO: implementar:
    -- - grade 66x66 com núcleo 2..65 (borda inerte)
    -- - estados 0..7 (0, C, S, R, CS, CR, SR, CSR)
    -- - parâmetros rec, dist, decaimento
    -- - duas fases por passo: manutenção e colonização
    -- - vizinhança de Moore 3x3
    -- - registros CSV e figuras (ver viz.lua)

    self.finalTime = params.finalTime or 500

    function self:step(t)
        -- TODO: lógica de manutenção e colonização
        -- (substituir por chamadas para funções auxiliares)
        return true
    end

    function self:run()
        for t = 1, self.finalTime do
            self:step(t)
        end
    end

    return self
end

return M
