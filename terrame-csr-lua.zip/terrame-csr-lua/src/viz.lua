-- viz.lua — geração de mapas/figuras (placeholders)
local V = {}

function V.render(state, t, outdir)
    -- TODO: renderizar um mapa simples por passo t
    -- Você pode salvar PPM/PNG conforme ferramentas disponíveis
end

return V
