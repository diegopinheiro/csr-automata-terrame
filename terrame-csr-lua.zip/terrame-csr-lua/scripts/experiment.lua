-- scripts/experiment.lua — rodar réplicas/cenários
local model = require("model")

local seeds = {1,2,3,4,5}
for _, s in ipairs(seeds) do
    math.randomseed(s)
    local m = model.new{ finalTime = 500 }
    m:run()
end
