-- scripts/validate.lua — comparação com séries do Java
-- TODO: ler CSVs gerados e comparar com séries de referência (se houver)
print("Validação: TODO — implementar leitura/plot/estatísticas.")
